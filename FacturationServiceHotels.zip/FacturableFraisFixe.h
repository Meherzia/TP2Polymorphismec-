#ifndef __FACTURABLEFRAISFIXE_H__
#define __FACTURABLEFRAISFIXE_H__
#include <iostream>
#include "ElementFacturable.h"
class FacturableFraisFixe : public ElementFacturable {
private:
	const float frais_spa = 75;
	const float frais_gym = 50;
	const float taxe_vente_base = 0.08;
	const float taxe_additionnelle = 0.07;
public:
	FacturableFraisFixe(std::string nom_unite)
		:ElementFacturable(nom_unite) {}
	virtual float CalculFacture();
};
#endif