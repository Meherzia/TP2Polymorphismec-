#include "FacturableParUnite.h"
#include <iostream>


float FacturableParUnite::CalculFacture() {

	if (this->getNom() == "Nuitees") {

		float facture = nb_Nuitees *(prix_nuitee+
			(prix_nuitee  * taxe_vente_base)
			+ (prix_nuitee * taxe_h�bergement));
		return facture;


	}
	else if (this->getNom() == "Repas") {

		float facture = nb_repas * (prix_repas +
			(prix_repas  *taxe_vente_base)
			+ (prix_repas *taxe_h�bergement));

		return facture;
	
	}
	else {
		std::cout << "Erreur!";
	}
}
void FacturableParUnite::Setnb_Nuitees(int nb_Nuitees) {
	nb_Nuitees = nb_Nuitees;
}
void FacturableParUnite::Setnb_repas(int nb_repas) {
	nb_repas = nb_repas;
}
