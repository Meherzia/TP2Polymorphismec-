
#ifndef __FACTURABLEPARUNITE_H__
#define __FACTURABLEPARUNITE_H__

#include <iostream>
#include "ElementFacturable.h"

class FacturableParUnite : public ElementFacturable {
private:
	int nb_Nuitees, nb_repas;
	const float prix_nuitee = 100;
	const float prix_repas = 20;
	const float taxe_vente_base = 0.08;
	const float taxe_h�bergement = 0.05;
public:
	void Setnb_Nuitees(int);
	void Setnb_repas(int);
	FacturableParUnite(std::string nom_unite,int nb_Nuitees,int nb_repas)
		:ElementFacturable(nom_unite) {
		this->nb_Nuitees = nb_Nuitees;
		this->nb_repas = nb_repas;
	}
	virtual float CalculFacture();
	
};

#endif
