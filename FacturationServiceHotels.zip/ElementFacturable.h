#ifndef __ELEMENTFACTURABLE_H__
#define __ELEMENTFACTURABLE_H__

#include <iostream>
#include <string>

class ElementFacturable {
private:
   std::string nom_unite;
public:
	ElementFacturable(std::string le_nom_unite) {
		this->nom_unite = le_nom_unite;
	}
	std::string getNom() 
	{ 
		return this->nom_unite; 
	}
	
	// Destructeur virtuel
	virtual ~ElementFacturable() {
	std::cout << "Destruction d'un element facturable." << std::endl;
	}

	// M�thode virtuelle pure
	virtual float CalculFacture() = 0;
};

#endif
