#include "FacturableFraisFixe.h"

float FacturableFraisFixe::CalculFacture() {

        if (this->getNom() == "Spa") {

	      float facture = frais_spa +
		   (frais_spa*taxe_vente_base)
		      + (frais_spa*taxe_additionnelle);

	     return facture;

        }
        else if (this->getNom() == "Gym") {
	        float facture = frais_gym +
		    (frais_gym*taxe_vente_base)
		           + (frais_gym*taxe_additionnelle);

	     return facture;
        }
        else {
	     std::cout << "Erreur!";
        }

}