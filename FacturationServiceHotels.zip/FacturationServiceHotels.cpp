#include <iostream>
#include <map>
#include "ElementFacturable.h"
#include "FacturableParUnite.h"
#include "FacturableFraisFixe.h"



int main() {
	// Arbre de paires ordonnées.
	std::map<int, ElementFacturable*> elements;
	int nb_Nuitees, nb_repas;
	
	int choix = 0;
	do {
		std::cout << "***Menu Principal***" << std::endl;
		std::cout << "  1. Ajouter des nuitees" << std::endl;
		std::cout << "  2. Ajouter des repas" << std::endl;
		std::cout << "  3. Ajouter un acces au spa" << std::endl;
		std::cout << "  4. Ajouter un acces au gym" << std::endl;
		std::cout << "  5. Afficher la facture et quitter" << std::endl;
		std::cin >> choix;

		switch (choix) {

		case 1:
		{
			try {
				if (elements.find(1) != elements.end()) throw std::out_of_range("La facture contient l'element nuitee!");
				std::cout << "Entrer le nombre de nuitees a passer a l'hotel: ";
				std::cin >> nb_Nuitees;
				if (nb_Nuitees <= 0) throw 1;
				FacturableParUnite* Nuitees = new FacturableParUnite("Nuitees", nb_Nuitees, 0);
				Nuitees->Setnb_Nuitees(nb_Nuitees);
				std::pair<int, ElementFacturable*> elt1(1, Nuitees);
				elements.insert(elt1);
				std::cout << "Ajout de nuitee a la facture!" << std::endl;
				
				
			}catch (const int& code_erreur) {
			std::cout << "ERR001:Nombre de nuitees est null!" << std::endl;
			}catch (std::out_of_range oor){
			std::cout <<oor.what()<< std::endl;
			}
		}
		break;
		case 2:
		{
			try {
				std::cout << "Entrer le nombre de repas a consommer a l'hotel: ";
				std::cin >> nb_repas;
				if (nb_repas <= 0) throw 2;
				
			FacturableParUnite* Repas = new FacturableParUnite("Repas",0,nb_repas);
			Repas->Setnb_repas(nb_repas);
			std::pair<int, ElementFacturable*> elt2(2, Repas);
			elements.insert(elt2);
			std::cout << "Ajout de repas a la facture!" << std::endl;
			}
			catch (const int& code_erreur) {
				std::cout << "ERR002:Nombre de repas est null!" << std::endl;
			}
		}


		break;
		case 3:
		{
			ElementFacturable* Spa = new FacturableFraisFixe("Spa");
			std::pair<int, ElementFacturable*> elt3(3, Spa);
			elements.insert(elt3);
			std::cout << "Ajout du service spa a la facture!" << std::endl;
		}
		break;
		case 4:
		{
			ElementFacturable* Gym = new FacturableFraisFixe("Gym");
			std::pair<int, ElementFacturable*> elt4(4, Gym);
			elements.insert(elt4);
			std::cout << "Ajout du service gym a la facture!" << std::endl;
		}
		break;
		case 5:
		{

		float Facture = 0;
		for (std::map<int, ElementFacturable*>::iterator it = elements.begin();
			it != elements.end(); it++) {
			Facture = it->second->CalculFacture()+ Facture;
		}
		std::cout << "La facture totale est: "<<Facture << "$" << std::endl;
		std::cout << "Bye bye !" << std::endl;
		}
		break;
		};
		// Il faut effacer nous même les "new"
		//vu qu'on a mis des pointeurs dans le conteneur. *sigh*

	} while (choix != 5);
	for (std::map<int, ElementFacturable*>::iterator it = elements.begin();
		it != elements.end(); it++) {
		delete it->second;
		it->second = NULL;
		
	}
};
